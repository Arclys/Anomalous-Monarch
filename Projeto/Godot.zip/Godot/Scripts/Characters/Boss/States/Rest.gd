extends BossState


func _begin_update() -> void:
	character.sprite.play("Idle")

func _update(delta: float) -> void:
	pass

func _physics_update(delta: float) -> void:
	if player_attacks_collided(): take_damage(1)
	
func _on_rest_timeout() -> void:
	state_machine.state_changer("attack")
